﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5._3
{
    [Serializable]
    public class Student
    {
        public int ID { get; set; }
        public string FullName { get; set; }
        public string Major { get; set; }
    }
}
